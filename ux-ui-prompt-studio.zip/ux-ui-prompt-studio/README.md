# UX/UI Prompt Studio

เครื่องมือช่วยสร้าง Prompt สำหรับงาน **Web Design** และ **Dashboard Design** เลือกตัวเลือก → ได้ Prompt พร้อมใช้กับ Claude, ChatGPT, Gemini, v0 / Lovable, Figma Make หรือ Cursor

A single-file web app that builds structured UX/UI prompts for website and dashboard projects.

## ฟีเจอร์

- **2 โหมด** — Web Design และ Dashboard Design ตัวเลือกเปลี่ยนตามโหมด
- **Web:** ประเภทเว็บ, Section (เรียงตามลำดับที่เลือก), Hero, Navigation, CTA, โทนข้อความ, SEO
- **Dashboard:** คำถามที่ต้องตอบ, KPI พร้อมเป้าหมาย, ชนิดกราฟ, ตัวกรอง, แหล่งข้อมูล, การอัปเดต, สถานะ RAG และกฎการออกแบบแดชบอร์ด
- **เทมเพลต** — Corporate Website, Product Landing, HR Intranet Portal, Campaign Microsite, Executive KPI, Factory OEE, HR & Learning, Sales Pipeline
- **ตรวจ Contrast สี** ตาม WCAG AA พร้อมตัวอย่างสีจริง
- **ปรับ Prompt ตาม AI** ที่จะใช้
- **รูปแบบ Prompt:** Full / Short / Visual only และเลือกภาษา EN / ไทย
- **Preset** บันทึกชุดตั้งค่าใน localStorage ของเบราว์เซอร์
- รองรับ Light / Dark mode และหน้าจอมือถือ

## การใช้งาน

เปิดไฟล์ `index.html` ในเบราว์เซอร์ได้ทันที ไม่ต้องติดตั้งหรือ build ใด ๆ

## Deploy ด้วย GitHub Pages

1. สร้าง repository ใหม่บน GitHub แล้วอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้
2. ไปที่ **Settings → Pages**
3. ที่ **Source** เลือก `Deploy from a branch` → branch `main` → โฟลเดอร์ `/ (root)` → **Save**
4. รอประมาณ 1–2 นาที เว็บจะอยู่ที่ `https://<username>.github.io/<repo-name>/`

หรือใช้ Git:

```bash
git init
git add .
git commit -m "Initial commit: UX/UI Prompt Studio"
git branch -M main
git remote add origin https://github.com/<username>/ux-ui-prompt-studio.git
git push -u origin main
```

## โครงสร้างไฟล์

```
ux-ui-prompt-studio/
├── index.html    # แอปทั้งหมด (HTML + CSS + JS ในไฟล์เดียว)
├── README.md
├── LICENSE
└── .gitignore
```

## ความเป็นส่วนตัว

ทำงานในเบราว์เซอร์ทั้งหมด ไม่ส่งข้อมูลออกไปภายนอก (โหลดเฉพาะฟอนต์จาก Google Fonts)

## License

MIT — ดูไฟล์ [LICENSE](LICENSE)
